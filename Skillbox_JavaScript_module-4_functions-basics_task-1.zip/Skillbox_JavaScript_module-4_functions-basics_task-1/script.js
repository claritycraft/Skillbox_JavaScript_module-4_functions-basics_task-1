// 1 вариант
function doSomething (a = 4, b = 5, c = 6) {
    console.log ('Вывод:', (a + b + c ) / 3);
}

doSomething ()


// 2 вариант
function doSomething () {
    let a = 4
    let b = 6
    let c = 5
    console.log ('Вывод:', (a + b + c ) / 3);
}

doSomething ()


// 3 вариант
const average = (a, b, c) => (a + b + c ) / 3;

console.log('Вывод:', average(4, 5, 6));





